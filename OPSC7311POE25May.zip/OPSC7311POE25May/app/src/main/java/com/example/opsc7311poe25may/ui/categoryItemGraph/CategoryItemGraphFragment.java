package com.example.opsc7311poe25may.ui.categoryItemGraph;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.opsc7311poe25may.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class CategoryItemGraphFragment extends Fragment implements View.OnClickListener {

    //Initialise variable
    private View categoryItemGraphView;
    private Spinner categoryNameSpinner;
    private Button get_graph_btn;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private BarChart barChart;
    private ArrayList<BarEntry> barEntries = new ArrayList<>();
    private BarDataSet barDataSet;
    private BarData theData;

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        categoryItemGraphView = inflater.inflate(R.layout.fragment_category_item_graph, container, false);

        //Assign variable
        categoryNameSpinner = (Spinner) categoryItemGraphView.findViewById(R.id.category_name_spinner_graph);
        get_graph_btn = (Button) categoryItemGraphView.findViewById(R.id.get_item_count_btn);
        barChart = (BarChart) categoryItemGraphView.findViewById(R.id.category_barChat);

        get_graph_btn.setOnClickListener(this);

        //get instance
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference fDatabaseRoot = database.getReference();

        //___________________code attribution_________________________________
        //The following code was taken from StackOverflow:
        //Author: Moreira,L
        //Link: https://stackoverflow.com/questions/49053155/how-can-i-populate-a-spinner-with-firebase-data
        fDatabaseRoot.child("Category").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Is better to use a List, because you don't know the size
                // of the iterator returned by dataSnapshot.getChildren() to
                // initialize the array
                final List<String> c = new ArrayList<String>();

                //get current user
                mAuth = FirebaseAuth.getInstance();
                currentUser = mAuth.getCurrentUser();

                String id = currentUser.getUid();

                //loops through category data
                for (DataSnapshot cName : dataSnapshot.getChildren()) {
                    String u = cName.child("user").getValue(String.class);
                    String name = cName.child("categoryName").getValue(String.class);

                    //checks if any user created a category
                    //if taken out, app crashes for user without a category
                    if (u != null) {
                        //checks if the category is equal to the user logged in
                        if (u.equals(id)) {
                            //checks if category exist
                            if (name != null) {
                                //add all category name
                                c.add(name);
                            }
                        }
                    }
                }

                ArrayAdapter<String> categoryNameAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, c);
                categoryNameAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                categoryNameSpinner.setAdapter(categoryNameAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                Toast.makeText(getActivity(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        return categoryItemGraphView;
    }
    //______________________________end_____________

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.get_item_count_btn:

                //___________________code attribution____________________
                //The following code was taken from StackOverFlow:
                //Author : Albert Jimenez G
                //Link: https://stackoverflow.com/questions/29891237/checking-if-spinner-is-selected-and-having-null-value-in-android
                //checks if category name is empty
                if (categoryNameSpinner.getCount()==0){
                    Toast.makeText(getActivity(), "Please create a category", Toast.LENGTH_SHORT).show();
                    return;
                }
                //___________________end___________________________________

                //checks if bar chart has been populated
                if(theData != null) {

                    //clears the bar entries
                    barEntries.clear();
                    //clears bar chart
                    barChart.clear();

                }

                //gets category name
                String name = categoryNameSpinner.getSelectedItem().toString();

                //gets firebase instance and creates item table
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference root = database.getReference("Item");

                //___________________code attribution_________________________________
                //The following code was taken from YouTube:
                //Author: Kachhadiya, C
                //Link: https://youtube.be/vhktbECeazQ

                //checks if category name is equal to name selected from spinner
                Query query = root.orderByChild("categoryName").equalTo(name);

                query.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        Float f = Float.valueOf(snapshot.getChildrenCount());
                        //int index = 0;
                        Toast.makeText(getActivity(),"Count is: " + f, Toast.LENGTH_SHORT).show();

                        //default entry
                        barEntries.add(new BarEntry(0f, 0));
                        //add category to bar graph
                        barEntries.add(new BarEntry(1f, snapshot.getChildrenCount()));
                        //barEntries.add(new BarEntry(40f, 1));

                        //sets the data
                        barDataSet = new BarDataSet(barEntries, name);
                        //sets color for text
                        barDataSet.setValueTextColor(Color.BLACK);
                        //sets text size
                        barDataSet.setValueTextSize(20f);

                        //get y axis
                        YAxis yAxis = barChart.getAxis(YAxis.AxisDependency.LEFT);
                        yAxis.setAxisMinimum(0f);
                        //shows no grid lines
                        yAxis.setDrawGridLines(false);

                        //gets y axis right side
                        YAxis yAxis1 = barChart.getAxis(YAxis.AxisDependency.RIGHT);
                        yAxis1.setAxisMinimum(0f);
                        //shows sno grid lines
                        yAxis1.setDrawGridLines(false);

                        //gets x axis
                        XAxis xAxis = barChart.getXAxis();
                        xAxis.setGranularity(1.0f);
                        xAxis.setGranularityEnabled(true);
                        xAxis.setDrawGridLines(false);

                        //disables right hand side of y axis
                        YAxis rightYAxis = barChart.getAxisRight();
                        rightYAxis.setEnabled(false);

                        theData = new BarData(barDataSet);

                        barChart.setFitBars(true);
                        //sets the data
                        barChart.setData(theData);
                        //sets description
                        barChart.getDescription().setText("Bar chart showing number of items in a category");
                        //sets animations
                        barChart.animateY(2000);

                        //------------------ end ---------------------
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                        //error message
                        Toast.makeText(getActivity(),error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

                break;
        }
    }
}