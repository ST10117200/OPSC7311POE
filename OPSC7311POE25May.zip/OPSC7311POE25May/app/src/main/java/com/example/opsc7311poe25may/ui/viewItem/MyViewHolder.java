package com.example.opsc7311poe25may.ui.viewItem;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.opsc7311poe25may.R;

class MyViewHolder extends RecyclerView.ViewHolder {

    //Initialise variable
    ImageView imageView;
    TextView itemName, categoryName, itemDesc, dateOfAcquisition;
    Button deleteItemBtn, shareItemBtn;

    public MyViewHolder(@NonNull View itemView) {

        //___________________code attribution____________________
        //The following code was taken from YouTube:
        //Author : Technical Skillz
        //Link: https://youtu.be/2EhlB4jqb48
        super(itemView);

        //Assign variable
        imageView = itemView.findViewById(R.id.image_view);
        itemName = itemView.findViewById(R.id.item_name_view);
        categoryName = itemView.findViewById(R.id.category_name_tv_view);
        itemDesc = itemView.findViewById(R.id.item_Desc_tv_view);
        dateOfAcquisition = itemView.findViewById(R.id.date_of_acquisition_tv_view);
        deleteItemBtn = itemView.findViewById(R.id.delete_item_btn);
        shareItemBtn = itemView.findViewById(R.id.shareItem_btn);

        //______________________________end_______________________
    }
}