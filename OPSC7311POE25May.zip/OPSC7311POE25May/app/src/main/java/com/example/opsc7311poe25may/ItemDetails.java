package com.example.opsc7311poe25may;

public class ItemDetails {

    //Initialise variable
    private String itemName;
    private String categoryName;
    private String itemDesc;
    private String dateOfAcquisition;
    private String imageUrl;
    private String user;

    //empty constructor
    public ItemDetails() {

    }

    //constructor will all variables
    public ItemDetails(String itemName, String categoryName, String itemDesc, String dateOfAcquisition, String imageUrl, String user) {
        this.itemName = itemName;
        this.categoryName = categoryName;
        this.itemDesc = itemDesc;
        this.dateOfAcquisition = dateOfAcquisition;
        this.imageUrl = imageUrl;
        this.user = user;
    }

    //get and set methods for variables

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getItemDesc() {
        return itemDesc;
    }

    public void setItemDesc(String itemDesc) {
        this.itemDesc = itemDesc;
    }

    public String getDateOfAcquisition() {
        return dateOfAcquisition;
    }

    public void setDateOfAcquisition(String dateOfAcquisition) {
        this.dateOfAcquisition = dateOfAcquisition;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    //to string methods to display all variables

    public String itemNameToString(){
        return "\nItem name: " + itemName;
    }

    public String categoryNameToString(){
        return "\nCategory name: " + categoryName;
    }

    public String itemDescriptionToString(){
        return "\nItem description: " + itemDesc;
    }

    public String dateOfAcquisition(){
        return "\nDate of acquisition: " + dateOfAcquisition;
    }
}