package com.example.opsc7311poe25may;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.opsc7311poe25may.ui.playGame.PlayGameFragment;
import com.example.opsc7311poe25may.ui.viewCategory.ViewCategoryFragment;

public class GameOver extends AppCompatActivity {

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Bhattacharya, S
    //Link: https://www.youtube.com/watch?v=YNq6B_VEvRI

    //Initialise variable
    TextView tvPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);
        int points = getIntent().getExtras().getInt("points");
        tvPoints = findViewById(R.id.tvPoints);
        tvPoints.setText("" + points);
    }

    //takes user to start up activity to play the game
    public void restart(View view) {
        Intent intent = new Intent(GameOver.this, StartUp.class);
        startActivity(intent);
        finish();
    }

    //takes user to play game fragment when exiting the game
    public void exit(View view) {
        Intent intentViewCategory = new Intent(GameOver.this, PlayGameFragment.class);
        startActivity(intentViewCategory);
        finish();
    }
    //___________________end_________________________________

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}