package com.example.opsc7311poe25may.ui.logout;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.opsc7311poe25may.LoginActivity;
import com.example.opsc7311poe25may.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LogoutFragment extends Fragment {

    //Initialise variable
    private View logoutView;
    private FirebaseAuth mAuth;

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        logoutView = inflater.inflate(R.layout.fragment_logout, container, false);

        //___________________code attribution____________________
        //The following code was taken from StackOverFlow:
        //Author : BK201
        //Link: https://stackoverflow.com/questions/48485190/android-studio-fragments-logout-function-with-firebase

        mAuth = FirebaseAuth.getInstance();

        //checks if there is a user logged in
        if (mAuth.getCurrentUser() != null) {
            //signs the user out
            mAuth.signOut();

            //redirects user to login
            Intent i = new Intent(getActivity(), LoginActivity.class);
            startActivity(i);
        }
        //______________________________end_____________

        return logoutView;
    }
    //______________________________end_____________
}