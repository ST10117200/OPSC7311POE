package com.example.opsc7311poe25may.ui.viewCategory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.opsc7311poe25may.CategoryDetails;
import com.example.opsc7311poe25may.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewCategoryFragment extends Fragment {

    FirebaseDatabase database = FirebaseDatabase.getInstance();

    //allows category table to be created
    DatabaseReference myRef = database.getReference("Category");

    //Initialise variable
    private View viewCategoryView;
    private ListView CategoryDisplay;
    private List<String> catList;
    private ArrayAdapter adapter;
    private CategoryDetails c;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        viewCategoryView = inflater.inflate(R.layout.fragment_view_category, container, false);

        //Assign variable
        CategoryDisplay = (ListView) viewCategoryView.findViewById(R.id.lvDisplayCategory);

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot)
            {
                c = new CategoryDetails();

                //array list
                catList = new ArrayList<String>();

                //gets firebase auth instance
                mAuth = FirebaseAuth.getInstance();

                //get current user
                currentUser = mAuth.getCurrentUser();

                //assigns current user to id variable
                String id = currentUser.getUid();

                //loops and gets all the category details
                for(DataSnapshot item:snapshot.getChildren())
                {
                    String u = item.child("user").getValue(String.class);

                    //checks user id
                    if(u.equals(id))
                    {
                        //gets all the category details
                        c = item.getValue(CategoryDetails.class);
                        //adds the details to the list
                        catList.add(c.ToString());
                    }
                }

                //array adapter
                adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1,catList);
                //populates the list view with category details
                CategoryDisplay.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error)
            {

                //error message
                Toast.makeText(getActivity(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        return viewCategoryView;
    }
    //______________________________end__________________________________
}