package com.example.opsc7311poe25may;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StartUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_up);
    }

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Bhattacharya, S
    //Link: https://www.youtube.com/watch?v=YNq6B_VEvRI

    //takes user to main game activity to play game
    public void startGame(View view) {
        startActivity(new Intent(this, MainGameActivity.class));
        finish();
    }
    //___________________end_________________________________

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}