package com.example.opsc7311poe25may.ui.viewItem;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.opsc7311poe25may.ItemDetails;
import com.example.opsc7311poe25may.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class ViewItemFragment extends Fragment {

    //Initialise variable
    private View viewItemView;
    private EditText inputSearch;
    private RecyclerView recyclerView;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private FirebaseRecyclerOptions<ItemDetails> options;
    private FirebaseRecyclerAdapter<ItemDetails, MyViewHolder> adapter;
    private DatabaseReference databaseReference;

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        viewItemView = inflater.inflate(R.layout.fragment_view_item, container, false);

        //___________________code attribution____________________
        //The following code was taken from YouTube:
        //Author : Technical Skillz
        //Link: https://youtu.be/TBRT1uWds3d
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Item");

        //Assign variable
        inputSearch = viewItemView.findViewById(R.id.inputSearch);
        recyclerView = viewItemView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        //______________________________end_____________

        //___________________code attribution____________________
        //The following code was taken from YouTube:
        //Author : Technical Skillz
        //Link: https://youtu.be/2EhlB4jqb48
        loadData("");
        //______________________________end_____________

        //___________________code attribution____________________
        //The following code was taken from YouTube:
        //Author : Technical Skillz
        //Link: https://www.youtube.com/watch?v=_nIoEAC3kLg&t=104s
        inputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString() != null) {
                    loadData(s.toString());
                } else {
                    loadData("");
                }
            }
        });
        //______________________________end_____________

        //returns view item view
        return viewItemView;
        //______________________________end_____________
    }

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Technical Skillz
    //Link: https://youtu.be/2EhlB4jqb48
    private void loadData(String data) {
        //___________________code attribution____________________
        //The following code was taken from YouTube:
        //Author : Technical Skillz
        //Link: https://www.youtube.com/watch?v=_nIoEAC3kLg&t=144s
        Query query = databaseReference.orderByChild("categoryName").startAt(data).endAt(data + "\uf8ff");
        //______________________________end_______________________
        options = new FirebaseRecyclerOptions.Builder<ItemDetails>().setQuery(query, ItemDetails.class).build();
        adapter = new FirebaseRecyclerAdapter<ItemDetails, MyViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull MyViewHolder holder, final int position, @NonNull ItemDetails model) {

                //gets auth instance
                mAuth = FirebaseAuth.getInstance();

                //get current user
                currentUser = mAuth.getCurrentUser();

                //gets current user
                String id = currentUser.getUid();

                //checks user in firebase is equal to current user
                String u = model.getUser();

                //checks user id
                if (u.equals(id))
                {
                    //gets that users item name, des, date of acquisition, image and the category it belongs to
                    holder.itemName.setText(model.itemNameToString());
                    holder.categoryName.setText(model.categoryNameToString());
                    holder.itemDesc.setText(model.itemDescriptionToString());
                    holder.dateOfAcquisition.setText(model.dateOfAcquisition());
                    Picasso.get().load(model.getImageUrl()).into(holder.imageView);
                }
                //______________________________end____________________________________________

                //___________________code attribution____________________
                //The following code was taken from YouTube:
                //Author : BTech Days
                //Link: https://www.youtube.com/watch?v=7VNrh09Epmw&t=2166s
                holder.deleteItemBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        AlertDialog.Builder builder = new AlertDialog.Builder(holder.itemName.getContext());
                        builder.setTitle("Are you sure you want to delete the item?");
                        builder.setMessage("Deleted data of item can't be undone");

                        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                FirebaseDatabase.getInstance().getReference().child("Item").child(getRef(holder.getAdapterPosition()).getKey()).removeValue();
                            }
                        });

                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                Toast.makeText(holder.itemName.getContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        });
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }
                });

                //___________________code attribution____________________
                //The following code was taken from YouTube:
                //Author : Coding Demos
                //Link: https://www.youtube.com/watch?v=SvTr9QA5NvA
                holder.shareItemBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intentShareItem = new Intent(Intent.ACTION_SEND);
                        intentShareItem.putExtra(Intent.EXTRA_TEXT, "Item name:" +  (model.getItemName()) +
                                        "\nCategory name:" + (model.getCategoryName()) +
                                        "\nItem description:" + (model.getItemDesc()) +
                                        "\nDate of acquisition:" + (model.getDateOfAcquisition()) +
                                        "\nImage url:" + (model.getImageUrl()));
                        intentShareItem.setType("text/image");

                        if(intentShareItem.resolveActivity(getActivity().getPackageManager())!= null)
                        {
                            startActivity(intentShareItem);
                        }

                    }
                });
                //______________________________end____________________________________________
            }

            @NonNull
            @Override
            public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view, parent, false);
                return new MyViewHolder(v);
            }
        };

        //starts adapter listening
        adapter.startListening();
        //sets recycler view
        recyclerView.setAdapter(adapter);
    }
    //______________________________end____________________________________________
}