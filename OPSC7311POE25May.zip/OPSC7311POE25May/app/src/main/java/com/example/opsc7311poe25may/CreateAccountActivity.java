package com.example.opsc7311poe25may;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.regex.Pattern;

public class CreateAccountActivity extends AppCompatActivity {

    //Initialise variable
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private TextView Login_tv;
    private Button Create_account_bt;
    private EditText Email_register_edtx, Password_register_edtx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        mAuth = FirebaseAuth.getInstance();
        //have on start or not because code is below
        currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            // reload();
        }

        //Assign variable
        Login_tv = findViewById(R.id.login_tv);
        Create_account_bt = findViewById(R.id.create_account_btn);
        Email_register_edtx = findViewById(R.id.email_register);
        Password_register_edtx = findViewById(R.id.password_register);

        //verify password for special character
        Pattern specialCharPatten = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        //verify password for uppercase
        Pattern UpperCasePatten = Pattern.compile("[A-Z ]");
        //verify password for lowercase
        Pattern lowerCasePatten = Pattern.compile("[a-z ]");
        //verify password for digit
        Pattern digitCasePatten = Pattern.compile("[0-9 ]");

        //Takes user to login activity
        Login_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //redirects user to create account activity
                Intent i = new Intent(CreateAccountActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });

        //Create account for new user
        Create_account_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Assign variable
                String email = Email_register_edtx.getText().toString();
                String password = Password_register_edtx.getText().toString();

                //Validation

                //checks if edit text for email is empty
                if (email.isEmpty()){
                    Email_register_edtx.setError("Email is required");
                    Email_register_edtx.requestFocus();
                    return;
                }

                //checks if email address is valid
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    Email_register_edtx.setError("Please enter a valid email");
                    Email_register_edtx.requestFocus();
                    return;
                }

                //checks if edit text for password is empty
                if(password.isEmpty()){
                    Password_register_edtx.setError("Password is required");
                    Password_register_edtx.requestFocus();
                    return;
                }

                //checks if password length is at least 6 characters long
                if(password.length() < 6){
                    Password_register_edtx.setError("Minimum password length is 6 characters");
                    Password_register_edtx.requestFocus();
                    return;
                }

                //------------------code attribution ------------------
                //The following code was taken from StackOverFlow:
                //Author : Ankur
                //Link: https://stackoverflow.com/questions/36097097/password-validate-8-digits-contains-upper-lowercase-and-a-special-character

                //checks if password has a special character, lowercase,uppercase and a digit
                if (!specialCharPatten.matcher(password).find() || !UpperCasePatten.matcher(password).find()
                        || !lowerCasePatten.matcher(password).find() || !digitCasePatten.matcher(password).find())
                {

                    Password_register_edtx.setError("Password must have at least one specail character, one uppercase," +
                            " one lowercase and one digit!");
                    Password_register_edtx.requestFocus();
                    return;
                }

                //---------------- end ------------------

                //creates user account
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(CreateAccountActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Toast.makeText(CreateAccountActivity.this, "Create User With Email: Successful", Toast.LENGTH_SHORT).show();

                                    currentUser = mAuth.getCurrentUser();

                                    //redirects user to login activity
                                    Intent i = new Intent(CreateAccountActivity.this, LoginActivity.class);
                                    startActivity(i);

                                    //updateUI(currentUser);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(CreateAccountActivity.this, "Create User With Email: Unsuccessful", Toast.LENGTH_SHORT).show();

                                    currentUser = null;
                                }
                            }
                        });

            }

        });
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}