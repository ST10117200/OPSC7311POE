package com.example.opsc7311poe25may;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainGameActivity extends AppCompatActivity {

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Bhattacharya, S
    //Link: https://www.youtube.com/watch?v=YNq6B_VEvRI

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new SpaceShooter(this));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    //___________________end_________________________________

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}