package com.example.opsc7311poe25may.ui.shareCategory;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.opsc7311poe25may.CategoryDetails;
import com.example.opsc7311poe25may.R;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ShareCategoryFragment extends Fragment implements View.OnClickListener{

    //Initialise variable
    private View ShareCategoryView;
    private Spinner categoryNameSpinner;
    private Button shareData;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private List<CategoryDetails> CategoryDetailsList =  new ArrayList<CategoryDetails>();
    private CategoryDetails cd = new CategoryDetails();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ShareCategoryView = inflater.inflate(R.layout.fragment_share_category, container, false);

        //Assign variable
        categoryNameSpinner = (Spinner) ShareCategoryView.findViewById(R.id.category_name_spinner_share);
        shareData = (Button) ShareCategoryView.findViewById(R.id.shareCategory_btn);

        shareData.setOnClickListener(this);

        //get instance
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference fDatabaseRoot = database.getReference();

        //___________________code attribution_________________________________
        //The following code was taken from StackOverflow:
        //Author: Moreira,L
        //Link: https://stackoverflow.com/questions/49053155/how-can-i-populate-a-spinner-with-firebase-data
        fDatabaseRoot.child("Category").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Is better to use a List, because you don't know the size
                // of the iterator returned by dataSnapshot.getChildren() to
                // initialize the array
                final List<String> c = new ArrayList<String>();

                //get current user
                mAuth = FirebaseAuth.getInstance();
                currentUser = mAuth.getCurrentUser();

                String id = currentUser.getUid();

                //loops through category data
                for (DataSnapshot cName : dataSnapshot.getChildren()) {
                    String u = cName.child("user").getValue(String.class);
                    String name = cName.child("categoryName").getValue(String.class);

                    //checks if any user created a category
                    //if taken out, app crashes for user without a category
                    if (u != null) {
                        //checks if the category is equal to the user logged in
                        if (u.equals(id)) {
                            //checks if category exist
                            if (name != null) {
                                //add all category name
                                c.add(name);

                                cd = cName.getValue(CategoryDetails.class);
                                CategoryDetailsList.add(cd);
                            }
                        }
                    }
                }

                ArrayAdapter<String> categoryNameAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, c);
                categoryNameAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                categoryNameSpinner.setAdapter(categoryNameAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                Toast.makeText(getActivity(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        return ShareCategoryView;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.shareCategory_btn:

                //___________________code attribution____________________
                //The following code was taken from StackOverFlow:
                //Author : Albert Jimenez G
                //Link: https://stackoverflow.com/questions/29891237/checking-if-spinner-is-selected-and-having-null-value-in-android
                //checks if category name is empty
                if (categoryNameSpinner.getCount()==0){
                    Toast.makeText(getActivity(), "Please create a category", Toast.LENGTH_SHORT).show();
                    return;
                }
                //___________________end___________________________________

                //gets category name
                String name = categoryNameSpinner.getSelectedItem().toString();
                //initialized variable
                String toGetCategoryDetails = "";

                //loops through every category details
                for (CategoryDetails categoryDetailsLoop : CategoryDetailsList) {

                    //checks if name from spinner is equal to any category name in firebase
                    if (categoryDetailsLoop.getCategoryName().equals(name)) {

                        //gets that category goal
                        toGetCategoryDetails = categoryDetailsLoop.ToString();

                    }
                }

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT, toGetCategoryDetails);
                intent.setType("text/plain");

                if(intent.resolveActivity(getActivity().getPackageManager())!= null){
                    startActivity(intent);
                }

                break;
        }
    }
}
