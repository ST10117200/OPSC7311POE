package com.example.opsc7311poe25may.ui.addItem;

import static android.app.Activity.RESULT_OK;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.opsc7311poe25may.ui.viewCategory.ViewCategoryFragment;
import com.example.opsc7311poe25may.ui.viewItem.ViewItemFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import com.example.opsc7311poe25may.ItemDetails;
import com.example.opsc7311poe25may.MenuActivity;
import com.example.opsc7311poe25may.R;

public class AddItemFragment extends Fragment implements View.OnClickListener {

    //Initialise variable
    private View addItemView;
    private DatePickerDialog datePickerDialog;
    private Button datePickerButton, itemButton, addItemButton, dateOfAcquisition_btn, image_btn;
    private Spinner categorySpinner;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private EditText itemName_edtx, itemDesc_edtx;
    private Uri imageUri;

    //gets firebase instance and creates item table
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference root = database.getReference("Item");

    //gets firebase storage instance and reference
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    StorageReference imagesRef = storageRef.child("images");

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        addItemView = inflater.inflate(R.layout.fragment_add_item, container, false);

        //Assign variable
        itemButton = (Button) addItemView.findViewById(R.id.image_btn);
        addItemButton = (Button) addItemView.findViewById(R.id.add_item_btn);
        categorySpinner = (Spinner) addItemView.findViewById(R.id.category_name_spinner);
        itemName_edtx = (EditText) addItemView.findViewById(R.id.item_name);
        itemDesc_edtx = (EditText) addItemView.findViewById(R.id.item_Desc);
        dateOfAcquisition_btn = (Button) addItemView.findViewById(R.id.date_picker_btn);
        image_btn = (Button) addItemView.findViewById(R.id.image_btn);
        datePickerButton = (Button) addItemView.findViewById(R.id.date_picker_btn);

        //set on click listener
        itemButton.setOnClickListener(this);
        addItemButton.setOnClickListener(this);
        datePickerButton.setOnClickListener(this);

        //get instance
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference fDatabaseRoot = database.getReference();

        //___________________code attribution_________________________________
        //The following code was taken from StackOverflow:
        //Author: Moreira,L
        //Link: https://stackoverflow.com/questions/49053155/how-can-i-populate-a-spinner-with-firebase-data
        fDatabaseRoot.child("Category").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Is better to use a List, because you don't know the size
                // of the iterator returned by dataSnapshot.getChildren() to
                // initialize the array
                final List<String> c = new ArrayList<String>();

                //get current user
                mAuth = FirebaseAuth.getInstance();
                currentUser = mAuth.getCurrentUser();

                String id = currentUser.getUid();

                //loops through category data
                for (DataSnapshot cName : dataSnapshot.getChildren()) {
                    String u = cName.child("user").getValue(String.class);
                    String name = cName.child("categoryName").getValue(String.class);

                    //checks if any user created a category
                    //if taken out, app crashes for user without a category
                    if (u != null) {
                        //checks if the category is equal to the user logged in
                        if (u.equals(id)) {
                            //checks if category exist
                            if (name != null) {
                                //add all category name
                                c.add(name);
                            }
                        }
                    }
                }

                ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, c);
                categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                categorySpinner.setAdapter(categoryAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //___________________end_________________________________

        return addItemView;
        //___________________end_________________________________
    }

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_btn:
                //___________________code attribution____________________
                //The following code was taken from YouTube:
                //Author : Coding STUFF
                //Link: https://youtu.be/9-oa4OS7IUQ
                Intent intent = new Intent();
                intent.setAction(intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, 2);
                //___________________end_________________________________
                break;
            case R.id.add_item_btn:

                //Assign variable
                String itemName = itemName_edtx.getText().toString();
                String itemDesc = itemDesc_edtx.getText().toString();

                //Validation
                //checks if item name empty
                if(itemName.isEmpty()){
                    itemName_edtx.setError("Item name is required");
                    itemName_edtx.requestFocus();
                    return;
                }
                //checks if item desc is empty
                if (itemDesc.isEmpty()){
                    itemDesc_edtx.setError("Category description is required");
                    itemDesc_edtx.requestFocus();
                    return;
                }

                //___________________code attribution____________________
                //The following code was taken from StackOverFlow:
                //Author : Albert Jimenez G
                //Link: https://stackoverflow.com/questions/29891237/checking-if-spinner-is-selected-and-having-null-value-in-android
                //checks if category name is empty
                if (categorySpinner.getCount()==0){
                    Toast.makeText(getActivity(), "Please create a category", Toast.LENGTH_SHORT).show();
                    return;
                }
                //___________________end___________________________________

                //checks if image url is not null
                if (imageUri != null) {
                    //upload the image to firebase
                    uploadToFirebase(imageUri);

                } else {
                    //if null, error message is displayed
                    Toast.makeText(getActivity(), "Please Upload Image!", Toast.LENGTH_SHORT).show();
                }

                break;

                //gets date
            case R.id.date_picker_btn:
                initDatePicker();
                datePickerButton.setText(getTodayDate());
                datePickerDialog.show();
                break;
        }
    }
    //___________________end_________________________________

    //___________________code attribution_________________________________
    //The following code was taken from YouTube
    //Author: Code With Cal
    //Link: https://www.youtube.com/watch?v=qCoidM98zNk

    //returns todays date
    private String getTodayDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);

        return makeDateString(day, month, year);
    }
    //___________________end_________________________________

    //___________________code attribution_________________________________
    //The following code was taken from YouTube
    //Author: Code With Cal
    //Link: https://www.youtube.com/watch?v=qCoidM98zNk
    private void initDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                month = month + 1;
                String date = makeDateString(day, month, year);
                datePickerButton.setText(date);
            }
        };
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        datePickerDialog = new DatePickerDialog(getActivity(), dateSetListener, year, month, day);
    }
    //___________________end_________________________________

    //___________________code attribution_________________________________
    //The following code was taken from YouTube
    //Author: Code With Cal
    //Link: https://www.youtube.com/watch?v=qCoidM98zNk
    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }
    //___________________end_________________________________

    //___________________code attribution_________________________________
    //The following code was taken from YouTube
    //Author: Code With Cal
    //Link: https://www.youtube.com/watch?v=qCoidM98zNk

    //gets month selected
    private String getMonthFormat(int month) {
        if (month == 1)
            return "JAN";
        if (month == 2)
            return "FEB";
        if (month == 3)
            return "MAR";
        if (month == 4)
            return "APR";
        if (month == 5)
            return "MAY";
        if (month == 6)
            return "JUN";
        if (month == 7)
            return "JUL";
        if (month == 8)
            return "AUG";
        if (month == 9)
            return "SEPT";
        if (month == 10)
            return "OCT";
        if (month == 11)
            return "NOV";
        if (month == 12)
            return "DEC";
        return "JAN";
    }
    //___________________end_________________________________

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Coding STUFF
    //Link: https://youtu.be/9-oa4OS7IUQ

    //gets image url
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
        }
    }
    //___________________end_________________________________

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Coding STUFF
    //Link: https://youtu.be/9-oa4OS7IUQ

    //this method upload the category items to firebase
    private void uploadToFirebase(Uri uri) {
        StorageReference fileRef = imagesRef.child(System.currentTimeMillis() + "." + getFileExtension(uri));
        fileRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        //Assign variable

                        //gets auth instance
                        mAuth = FirebaseAuth.getInstance();
                        //gets current user
                        currentUser = mAuth.getCurrentUser();

                        String id = currentUser.getUid();
                        String itemName = itemName_edtx.getText().toString();
                        String categoryName = categorySpinner.getSelectedItem().toString();
                        String itemDescription = itemDesc_edtx.getText().toString();
                        String dateOfAcquisition = dateOfAcquisition_btn.getText().toString();
                        //call the item detail class.
                        ItemDetails itemDetails = new ItemDetails(itemName, categoryName, itemDescription, dateOfAcquisition, uri.toString(), id);
                        //gives each item an unique container key
                        String item = root.push().getKey();
                        //add items to firebase
                        root.child(item).setValue(itemDetails);
                        //display message to user
                        Toast.makeText(getActivity(), "Successfully Uploaded!", Toast.LENGTH_SHORT).show();

                        //clears edit text for item name and description
                        itemName_edtx.getText().clear();
                        itemDesc_edtx.getText().clear();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                //error message if item upload failed
                Toast.makeText(getActivity(), "Uploading failed!", Toast.LENGTH_SHORT).show();
            }
        });
    }
    //___________________end_________________________________

    //___________________code attribution____________________
    //The following code was taken from YouTube:
    //Author : Coding STUFF
    //Link: https://youtu.be/9-oa4OS7IUQ

    //gets the image url
    private String getFileExtension(Uri mUri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }
    //___________________end_________________________________
}
    
    
    
    