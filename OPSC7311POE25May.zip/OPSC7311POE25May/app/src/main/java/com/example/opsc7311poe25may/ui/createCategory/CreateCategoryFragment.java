package com.example.opsc7311poe25may.ui.createCategory;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.opsc7311poe25may.CategoryDetails;
import com.example.opsc7311poe25may.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateCategoryFragment extends Fragment implements View.OnClickListener {

    //Initialise variable
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private View createCategoryView;
    private EditText CategoryName_edtx, CategoryDes_edtx, CategoryGoal_edtx;
    private Button CreateCategory_btn;

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        createCategoryView = inflater.inflate(R.layout.fragment_create_category, container, false);

        //Assign variable
        CreateCategory_btn = (Button) createCategoryView.findViewById(R.id.createCategory);

        CreateCategory_btn.setOnClickListener(this);

        //Assign variable
        CategoryName_edtx = (EditText) createCategoryView.findViewById(R.id.categoryName);
        CategoryDes_edtx = (EditText) createCategoryView.findViewById(R.id.categoryDes);
        CategoryGoal_edtx = (EditText) createCategoryView.findViewById(R.id.categoryGoal);

        return createCategoryView;
    }
    //______________________________end__________________________________

    //___________________code attribution____________________
    //The following code was taken from StackOverFlow:
    //Author : Mohanraj, S
    //Link: https://stackoverflow.com/questions/11857022/fragment-implements-onclicklistener
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.createCategory:

                //gets firebase instance
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                //allows category table to be created
                DatabaseReference myRef = database.getReference("Category");

                //gets firebase auth instance
                mAuth = FirebaseAuth.getInstance();
                //gets current user
                currentUser = mAuth.getCurrentUser();

                //Assign variable
                String user = currentUser.getUid();
                String catName = CategoryName_edtx.getText().toString();
                String catDes = CategoryDes_edtx.getText().toString();
                String catGoal = CategoryGoal_edtx.getText().toString();

                //Validation
                //checks if edit text for category name is empty
                if(catName.isEmpty()){
                    CategoryName_edtx.setError("Category name is required");
                    CategoryName_edtx.requestFocus();
                    return;
                }

                //checks if edit text for category description is empty
                if (catDes.isEmpty()){
                    CategoryDes_edtx.setError("Category description is required");
                    CategoryDes_edtx.requestFocus();
                    return;
                }

                //checks if edit text for category is empty
                if (catGoal.isEmpty()){
                    CategoryGoal_edtx.setError("Category goal is required");
                    CategoryGoal_edtx.requestFocus();
                    return;
                }

                //get a unique container number for category
                String key = myRef.push().getKey();
                CategoryDetails cd = new CategoryDetails(catName, catDes, catGoal, user);

                //pushes category details to firebase
                myRef.child(key).setValue(cd);

                //message to tell user category is created
                Toast.makeText(getActivity(), "Category is successfully created!", Toast.LENGTH_SHORT).show();

                //clear edit text for category name, description and goal
                CategoryName_edtx.getText().clear();
                CategoryDes_edtx.getText().clear();
                CategoryGoal_edtx.getText().clear();

                break;
        }
    }
    //______________________________end__________________________________
}