package com.example.opsc7311poe25may;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {

    //Initialise variable
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private TextView Forgot_password_tv, Create_account_tv;
    private Button Login_bt;
    private EditText Email_login_edtx, Password_login_edtx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        //have on start or not because code is below
        currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            // reload();
        }

        //Assign variable
        Login_bt = findViewById(R.id.login_btn);
        Email_login_edtx = findViewById(R.id.email_login);
        Password_login_edtx = findViewById(R.id.password_login);
        Forgot_password_tv = findViewById(R.id.forgot_password);
        Create_account_tv = findViewById(R.id.create_account_tv);

        //verify password for special character
        Pattern specialCharPatten = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
        //verify password for uppercase
        Pattern UpperCasePatten = Pattern.compile("[A-Z ]");
        //verify password for lowercase
        Pattern lowerCasePatten = Pattern.compile("[a-z ]");
        //verify password for digit
        Pattern digitCasePatten = Pattern.compile("[0-9 ]");

        //Takes user to reset password activity
        Forgot_password_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //redirects user to reset password activity
                Intent i = new Intent(LoginActivity.this, ResetPasswordActivity.class);
                startActivity(i);
            }
        });

        //Allows user to login to account
        Login_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Assign variable
                String email = Email_login_edtx.getText().toString();
                String password = Password_login_edtx.getText().toString();

                //Validation

                //checks if edit text for email is empty
                if (email.isEmpty()){
                    Email_login_edtx.setError("Email is required");
                    Email_login_edtx.requestFocus();
                    return;
                }

                //checks if edit text for password is empty
                if(password.isEmpty()){
                    Password_login_edtx.setError("Password is required");
                    Password_login_edtx.requestFocus();
                    return;
                }

                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                                    currentUser = mAuth.getCurrentUser();

                                    //directs user to menu bar
                                    Intent i = new Intent(LoginActivity.this, MenuActivity.class);
                                    startActivity(i);

                                } else {
                                    // If sign in fails, display a message to the user.
                                    Toast.makeText(LoginActivity.this, "Login unsuccessful!", Toast.LENGTH_SHORT).show();

                                    currentUser = null;
                                }
                            }
                        });
            }

        });

        //Takes user to reset password activity
        Create_account_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //redirects user to create account activity
                Intent i = new Intent(LoginActivity.this, CreateAccountActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}