package com.example.opsc7311poe25may;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ResetPasswordActivity extends AppCompatActivity {

    //Initialise variable
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    private EditText Email_reset_password_edtx;
    private Button Forgot_password_btn, Back_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        //gets auth instance
        mAuth = FirebaseAuth.getInstance();
        //have on start or not coz code is below
        currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            // reload();
        }

        //Assign variable
        Email_reset_password_edtx = findViewById(R.id.email_reset_password_edtx);
        Forgot_password_btn = findViewById(R.id.reset_password);
        Back_btn = findViewById(R.id.back);

        //Reset password for account
        Forgot_password_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //extract the username and send reset password link
                String mail = Email_reset_password_edtx.getText().toString();

                //Validation
                if(!Patterns.EMAIL_ADDRESS.matcher(mail).matches()){
                    Email_reset_password_edtx.setError("Please enter a valid email");
                    Email_reset_password_edtx.requestFocus();
                    return;
                }

                mAuth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        //link sent, message will be displayed
                        Toast.makeText(ResetPasswordActivity.this, "Reset link has been sent to your email", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //link not sent, error message
                        Toast.makeText(ResetPasswordActivity.this, "Error! Reset link is not sent" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        //Back button to take the user to login activity, if user does not want to reset their password
        Back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(ResetPasswordActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}