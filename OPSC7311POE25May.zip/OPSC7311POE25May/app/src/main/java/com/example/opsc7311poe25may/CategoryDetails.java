package com.example.opsc7311poe25may;

public class CategoryDetails {

    //Initialise variable
    private String categoryName;
    private String categoryDescription;
    private String categoryGoal;
    private String user;

    //Constructor for all variables
    public CategoryDetails(String categoryName, String categoryDescription, String categoryGoal, String user) {
        this.categoryName = categoryName;
        this.categoryDescription = categoryDescription;
        this.categoryGoal = categoryGoal;
        this.user = user;
    }

    //empty constructor
    public CategoryDetails(){

    }

    //Getter and Setter for variables
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryDescription() {
        return categoryDescription;
    }

    public void setCategoryDescription(String categoryDescription) {
        this.categoryDescription = categoryDescription;
    }

    public String getCategoryGoal() {
        return categoryGoal;
    }

    public void setCategoryGoal(String categoryGoal) {
        this.categoryGoal = categoryGoal;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }


    //to string method to return category details
    public String ToString(){
        return "\nCategory name: " + categoryName + "\nCategory description: " +
                categoryDescription + "\nCategory goal: " + categoryGoal;
    }
}